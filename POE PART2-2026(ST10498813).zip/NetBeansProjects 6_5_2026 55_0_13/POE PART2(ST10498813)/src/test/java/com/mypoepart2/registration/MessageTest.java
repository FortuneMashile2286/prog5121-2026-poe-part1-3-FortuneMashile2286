/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mypoepart2.registration;


import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author fortune
 */


public class MessageTest {

    // TEST 1: Message length success (under 250 chars)
  
    @Test
    public void testMessageLengthSuccess() {
        Message msg = new Message();
        msg.setMessage("Hi Mike, can you join us for dinner tonight?");
        
        String result = msg.checkMessageLength();
        
        assertEquals("Message ready to send.", result);
    }
    
   
    // TEST 2: Message length failure (over 250 chars)
   
    @Test
    public void testMessageLengthFailure() {
        Message msg = new Message();
        
        // Build a message that is 260 characters (10 over)
        StringBuilder longMsg = new StringBuilder();
        for (int i = 0; i < 260; i++) {
            longMsg.append("a");
        }
        
        msg.setMessage(longMsg.toString());
        String result = msg.checkMessageLength();
        
        assertEquals("Message exceeds 250 characters by 10 ; please reduce the size.", result);
    }
    
    
    // TEST 3: Recipient number success
   
    @Test
    public void testRecipientNumberSuccess() {
        Message msg = new Message();
        msg.setRecipient("+2771869300");
        
        String result = msg.checkRecipientCell();
        
        assertEquals("Cell phone number successfully captured.", result);
    }
    
    
    // TEST 4: Recipient number failure
    
    @Test
    public void testRecipientNumberFailure() {
        Message msg = new Message();
        msg.setRecipient("2771869300"); // No + or 0 at start
        
        String result = msg.checkRecipientCell();
        
        assertEquals("Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.", result);
    }
    
   
    // TEST 5: Message hash is correct (Test Case 1)
   
    @Test
    public void testMessageHashCorrect() {
        Message msg = new Message();
        msg.setMessage("Hi Mike, can you join us for dinner tonight?");
        msg.setNumMessagesSent(0);
        msg.generateMessageID();
        
        String firstTwoDigits = msg.getMessageID().substring(0, 2);
        String expectedHash = firstTwoDigits + ":0:HITONIGHT";
        String actualHash = msg.createMessageHash();
        
        assertEquals(expectedHash, actualHash);
    }
    
   
    // TEST 6: Message ID is created
  
    @Test
    public void testMessageIDIsCreated() {
        Message msg = new Message();
        String id = msg.generateMessageID();
        
        assertNotNull(id, "Message ID should not be null");
        assertEquals(10, id.length(), "Message ID should be 10 digits");
        assertTrue(id.matches("\\d{10}"), "Message ID should only contain numbers");
    }
    
  
    // TEST 7: Send message option
    
    @Test
    public void testSendMessageOption() {
        Message msg = new Message();
        msg.setMessage("Test message");
        msg.setRecipient("+2712345678");
        msg.generateMessageID();
        msg.createMessageHash();
        
        // Simulate the send action by directly testing the logic
        // The sentMessage() method shows a dialog, so we test the outcome
        // by checking the total increases when we manually simulate a send
        int before = msg.getTotalMessages();
        
        // Since sentMessage() uses JOptionPane, we test storeMessage 
        // which is the other main action that doesn't need user input
        msg.storeMessage();
        
        // Test that store runs without error
        assertTrue(true, "Store message should complete without error");
    }
    
    // =============================================
    // TEST 8: Store message option
    // =============================================
    @Test
    public void testStoreMessageOption() {
        Message msg = new Message();
        msg.setMessage("Test message for storing");
        msg.setRecipient("+2712345678");
        msg.generateMessageID();
        msg.createMessageHash();
        
        try {
            msg.storeMessage();
            assertTrue(true, "Message successfully stored");
        } catch (Exception e) {
            fail("Store message should not throw exception: " + e.getMessage());
        }
    }
    
    
    // TEST 9: Total messages count
  
    @Test
    public void testReturnTotalMessages() {
        Message msg = new Message();
        
        // Should start at 0
        assertEquals(0, msg.returnTotalMessages(), "Total should start at 0");
        
        // Test that getTotalMessages also works
        assertEquals(0, msg.getTotalMessages(), "Get total should return 0");
    }
    
} 