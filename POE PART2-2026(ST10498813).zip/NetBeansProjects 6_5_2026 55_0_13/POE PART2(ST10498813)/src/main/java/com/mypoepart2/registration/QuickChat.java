/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mypoepart2.registration;

/**
 *
 * @author fortune
 */
import javax.swing.JOptionPane;
public class QuickChat {
   
    
    
    // This runs after login is successful
    public void startQuickChat(String firstName, String lastName) {
        
        // Create a Message object to handle messages
        Message msg = new Message();
        
        // This controls the main loop
        boolean running = true;
        
        // Ask user how many messages they want to send (Requirement 5)
        String numInput = JOptionPane.showInputDialog(null,"How many messages do you wish to enter?"+"Message Limit");
        
        // If user cancels, say goodbye and exit
        if (numInput == null) {
            JOptionPane.showMessageDialog(null,"Thank you for using QuickChat, " + firstName + "!" + "Goodbye");
            System.exit(0);
        }
        
        // Convert the input to a number
        int numMessages;
        try {
            numMessages = Integer.parseInt(numInput);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null,"Please enter a valid number." + "Error");
            return;
        }
        
        // Counter to track how many messages processed
        int messagesProcessed = 0;
        
        
        // Runs until user quits OR reaches message limit (Requirement 4)
        
        while (running && messagesProcessed < numMessages) {
            
            // Create menu options (Requirement 3)
            String[] menuOptions = {
                "1) Send Messages", 
                "2) Show recently sent messages", 
                "3) Quit"
            };
            
            // Show the menu as a pop-up with buttons
            int menuChoice = JOptionPane.showOptionDialog(
                null,
                "Please select an option:",     
                "QuickChat - Main Menu",        
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                menuOptions,                    
                menuOptions[0]                
            );
            
            
          
            // SEND MESSAGES
            if (menuChoice == 0) {
                
                // Generate Message ID
                msg.generateMessageID();
                JOptionPane.showMessageDialog(null, "Message ID generated: " + msg.getMessageID() + "Message ID" );
                
                
                //Get Recipient Number
                String recipient = JOptionPane.showInputDialog(null,"Enter recipient cell number:\n" +"(Include country code like +27 or 0)\n " + "Example: +27123456789 or 0812345678" + "Recipient Number");
                 
                // If user cancels, go back to main menu
                if (recipient == null) {
                    continue;
                }
                
                // Save the recipient number
                msg.setRecipient(recipient);
                
                // Check if the number is valid
                String recipientCheck = msg.checkRecipientCell();
                
                if (recipientCheck.contains("incorrectly formatted")) {
                    // Number is wrong - show error
                    JOptionPane.showMessageDialog(
                        null, 
                        recipientCheck + "\n\n" +
                        "The number must:\n" +
                        "- Start with + or 0 (international code)\n" +
                        "- Have no more than 10 digits after the code" +
                        "Invalid Number" );
                    continue; 
                } 
                else {
                    // Number is good - show success
                    JOptionPane.showMessageDialog(null,recipientCheck +"Number Validated");
                      
                    
                }
                
                
                // Get Message Content 
                String messageContent = JOptionPane.showInputDialog(
                    null, 
                    "Enter your message (maximum 250 characters):",
                    "Message Content" 
                    
                );
                
                // If user cancels, go back to main menu
                if (messageContent == null) {
                    continue;
                }
                
                // Save the message
                msg.setMessage(messageContent);
                
                // Check if message is too long (Requirement 6)
                String lengthCheck = msg.checkMessageLength();
                
                if (lengthCheck.contains("exceeds")) {
                    // Message too long - show error
                    JOptionPane.showMessageDialog(null,lengthCheck + "Message Too Long" );
                    continue; 
                } 
                else {
                    // Message length is okay
                    JOptionPane.showMessageDialog(null, "Message sent" + "Message Length OK");
                  
                }
                
                
                // Create Message Hash 
                String hash = msg.createMessageHash();
                JOptionPane.showMessageDialog(null, "Message Hash: " + hash + "Hash Generated" );
                
                
                
                // Ask user to Send, Disregard, or Store
                String result = msg.sentMessage();
                
                // Show what happened
                JOptionPane.showMessageDialog(null,result + "Action Result");
                
                
                // --- Step 6: Handle the Result ---
                if (result.equals("Message successfully sent")) {
                    // Add message to our list
                    msg.addMessageToList();
                    
                    // Display message details (Requirement 7)
                    // Order: ID, Hash, Recipient, Message
                    String details = "USER MESSAGE DETAILS\n\n" +
                                    "Message ID: " + msg.getMessageID() + "\n" +
                                    "Message Hash: " + hash + "\n" +
                                    "Recipient: " + recipient + "\n" +
                                    "Message: " + messageContent;
                    
                    JOptionPane.showMessageDialog(null,details+"Message Sent Successfully");
                }
                else if (result.equals("Message successfully stored")) {
                    // Save message to JSON file
                    msg.storeMessage();
                }
                else if (result.equals("Press 0 to delete the message")) {
                    // Message was disregarded
                }
                
                // Increase the counter
                messagesProcessed++;
                
                // Tell user how many messages they have left
                int remaining = numMessages - messagesProcessed;
                if (remaining > 0) {
                    JOptionPane.showMessageDialog(null,"Messages remaining: " + remaining + "Progress" );
                }
                
            }
            
           
             //SHOW RECENTLY SENT MESSAGES
            else if (menuChoice == 1) {
                // Feature still being developed 
                JOptionPane.showMessageDialog(null,"Coming Soon." + "Feature Not Available" );
            }
             // User wants to exit 
            else {
                 
                running = false;
            }
            
        } 
        // Show goodbye message with total count 
        if (!running) {
            // User chose to quit
            JOptionPane.showMessageDialog( null,  "Thank you for using QuickChat, " 
                    + firstName + "!\n\n" + "Total messages sent: " + msg.returnTotalMessages() + "Goodbye" );
        } 
        else if (messagesProcessed >= numMessages) {
            // User reached message limit
            JOptionPane.showMessageDialog(null,"You have reached your message limit.\n\n" + "Total messages sent: " + msg.returnTotalMessages()+ "Session Complete" );
        }
        
        // Display all messages that were sent
        String allMsgs = msg.printMessages();
        JOptionPane.showMessageDialog(null,allMsgs+ "Message History" );
        
    } 
    
} 
    
    

