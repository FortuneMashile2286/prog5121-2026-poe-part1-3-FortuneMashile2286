/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mypoepart2.registration;

/**
 *
 * @author fortune
 */
import java.io.FileWriter; 
import java.io.IOException; 
import java.util.ArrayList; 
import java.util.Random;   
import javax.swing.JOptionPane; 

public class Message {
   
    // These store all the info about each message
    private String messageID;       
    private String messageHash;     
    private String recipient;       
    private String message;         
    private int numMessagesSent;   
    private int totalMessages;     
    private ArrayList<String> allMessages; 
    
    
   
    // Sets up the starting values
    public Message() {
        allMessages = new ArrayList<>();
        numMessagesSent = 0;             
        totalMessages = 0;             
    }
    
    // These let us put values into our variables
    
    public void setRecipient(String recipient) {
        this.recipient = recipient;
    }
    
    public void setMessage(String message) {
        this.message = message;
    }
    
    public void setNumMessagesSent(int num) {
        this.numMessagesSent = num;
    }
    
   
    // These let us get values from our variables
    
    public String getMessageID() {
        return messageID;
    }
    
    public String getMessageHash() {
        return messageHash;
    }
    
    public String getRecipient() {
        return recipient;
    }
    
    public String getMessage() {
        return message;
    }
    
    public int getTotalMessages() {
        return totalMessages;
    }
    
    public int getNumMessagesSent() {
        return numMessagesSent;
    }
    
    // Creates a random 10-digit number for tracking
    public String generateMessageID() {
        Random rand = new Random();
        StringBuilder id = new StringBuilder();
        
        // Loop 10 times to create 10 random digits
        for (int i = 0; i < 10; i++) {
            int digit = rand.nextInt(10); 
            id.append(digit);             
        }
        
        messageID = id.toString(); 
        return messageID;         
    }
    
    // Makes sure ID is 10 characters or less
    public boolean checkMessageID() {
        if (messageID != null && messageID.length() <= 10) {
            return true;  
        }
        return false;    
    }
   
    // Makes sure phone number is formatted correctly
    public String checkRecipientCell() {
        
        // Check if the number is empty
        if (recipient == null || recipient.length() == 0) {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
        
        // Check if it starts with + (international code)
        if (recipient.startsWith("+")) {
            String numberOnly = recipient.substring(1); 
            
            if (numberOnly.length() <= 10) {
                return "Cell phone number successfully captured.";
            }
            else {
                return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
            }
        }
        
        // Check if it starts with 0 (local code)
        if (recipient.startsWith("0")) {
            if (recipient.length() <= 10) {
                return "Cell phone number successfully captured.";
            }
            else {
                return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
            }
        }
        
        // If it doesnt start with + or 0, its missing international code
        return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
    }
    
    // Makes a code like "00:0:HITONIGHT"
    public String createMessageHash() {
        
        // Get first two numbers from message ID
        String firstTwo = messageID.substring(0, 2);
        
        // Split message into separate words
        String[] words = message.split(" ");
        
        // Get the first word
        String firstWord = words[0];
        
        // Get the last word
        String lastWord = words[words.length - 1];
        
        // Remove punctuation from last word (? ! . , etc)
        lastWord = lastWord.replaceAll("[^a-zA-Z0-9]", "");
        
        // Put it all together in UPPERCASE
        messageHash = firstTwo + ":" + numMessagesSent + ":" + 
                      firstWord.toUpperCase() + lastWord.toUpperCase();
        
        return messageHash;
    }
    
    // Shows 3 options: Send, Disregard, or Store
    public String sentMessage() {
        
        String[] options = {
            "Send Message", 
            "Disregard Message", 
            "Store Message to send later"
        };
        
        int choice = JOptionPane.showOptionDialog(
            null,
            "What do you want to do with this message?",
            "Message Options",
            JOptionPane.DEFAULT_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            options,
            options[0]
        );
        
        // Check which button user clicked
        if (choice == 0) {         
            totalMessages++;
            numMessagesSent++;
            return "Message successfully sent";
        }
        else if (choice == 1) {     
            return "Press 0 to delete the message";
        }
        else if (choice == 2) {     
            return "Message successfully stored";
        }
        else {
            return "No action selected";
        }
    }
    
    // Makes sure message is under 250 characters
    public String checkMessageLength() {
        
        if (message.length() <= 250) {
            return "Message ready to send.";
        }
        else {
            int extra = message.length() - 250;
            return "Message exceeds 250 characters by " + extra + " ; please reduce the size.";
        }
    }
    
    // Returns all messages sent so far
    public String printMessages() {
        
        if (allMessages.isEmpty()) {
            return "No messages to display.";
        }
        
        StringBuilder output = new StringBuilder();
        output.append("=== All Messages Sent ===\n\n");
        
        for (int i = 0; i < allMessages.size(); i++) {
            output.append(allMessages.get(i));
            
            if (i < allMessages.size() - 1) {
                output.append("\n-------------------\n");
            }
        }
        
        return output.toString();
    }
    
    
    // Return Total Messages
    public int returnTotalMessages() {
        return totalMessages;
    }
    
    
    //Store Message to JSON File
    public void storeMessage() {
        try {
            // Build JSON string
            StringBuilder json = new StringBuilder();
            json.append("{\n");
            json.append("  \"messageID\": \"" + messageID + "\",\n");
            json.append("  \"messageHash\": \"" + messageHash + "\",\n");
            json.append("  \"recipient\": \"" + recipient + "\",\n");
            json.append("  \"message\": \"" + message + "\"\n");
            json.append("}");
            
            // Write to file
            FileWriter writer = new FileWriter("messages.json", true);
            writer.write(json.toString() + ",\n");
            writer.close();
            
            JOptionPane.showMessageDialog(null, 
                "Message saved to messages.json file!");
                
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null,"Error: Could not save message. " + e.getMessage() + "File Error");
        }
    }
    
    
    // Add Message To List
    public void addMessageToList() {
        String details = "Message ID: " + messageID + "\n" +
                        "Message Hash: " + messageHash + "\n" +
                        "Recipient: " + recipient + "\n" +
                        "Message: " + message;
        
        allMessages.add(details);
    }
}
    

