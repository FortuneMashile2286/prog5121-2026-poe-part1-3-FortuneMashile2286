/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mypoepart2.registration;

/**
 *
 * @author fortune
 */
import javax.swing.JOptionPane;
public class Login {
    
    
    // Variables to store registered details
    private String storedUsername;
    private String storedPassword;
    private String storedCellNumber;
    private String storedFirstName;
    private String storedLastName;
    
    // Variable to track if login was successful
    private boolean loginSuccess = false;

    // Constructor - gets data from Registration
    public Login(String username, String password, String cellNumber, 
                 String firstName, String lastName) {
        this.storedUsername = username;
        this.storedPassword = password;
        this.storedCellNumber = cellNumber;
        this.storedFirstName = firstName;
        this.storedLastName = lastName;
    }

    // Method to check username format
    public boolean checkUserName(String userName) {
        return userName.contains("_") && userName.length() <= 5;
    }

    // Method to check password complexity
    public boolean checkPasswordComplexity(String password) {
        
        boolean hasNumber = false;
        boolean hasCap = false;
        boolean hasChar = false;
        char current;
        
        // Loop through each character
        for (int i = 0; i < password.length(); i++) {
            current = password.charAt(i);

            if (Character.isDigit(current)) {
                hasNumber = true;
            }
            else if (Character.isUpperCase(current)) {
                hasCap = true;
            }
            else if (!(Character.isLetterOrDigit(current))) {
                hasChar = true;
            }
        }
        
        // Check all conditions
        return password.length() >= 8 && hasNumber && hasCap && hasChar;
    }

    // Method to check cellphone format
    public boolean checkCellPhoneNumber(String cell) {
        return cell.startsWith("+27") && cell.length() == 12;
    }

    // Main login process
    public void startLogin() {
        
        boolean loggedIn = false;

        // Loop until user enters correct details
        while (!loggedIn) {

            JOptionPane.showMessageDialog(null, "-- PLEASE LOGIN --");

            // Ask for name
            String firstName = JOptionPane.showInputDialog("Enter your first name:");
            
            // If user clicks cancel, exit
            if (firstName == null) {
                System.exit(0);
            }
            
            String lastName = JOptionPane.showInputDialog("Enter your last name:");
            
            // If user clicks cancel, exit
            if (lastName == null) {
                System.exit(0);
            }

            // Username loop
            String username;
            do {
                username = JOptionPane.showInputDialog("Enter username:");
                
                // If user clicks cancel, exit
                if (username == null) {
                    System.exit(0);
                }

                if (!checkUserName(username)) {
                    JOptionPane.showMessageDialog(null, 
                        "Username must contain '_' and be max 5 characters.");
                }

            } while (!checkUserName(username));

            // Password loop
            String password;
            do {
                password = JOptionPane.showInputDialog("Enter password:");
                
                // If user clicks cancel, exit
                if (password == null) {
                    System.exit(0);
                }

                if (!checkPasswordComplexity(password)) {
                    JOptionPane.showMessageDialog(null, 
                        "Password must be at least 8 characters and include capital letter, number and special character.");
                }

            } while (!checkPasswordComplexity(password));

            // Cell number loop
            String cell;
            do {
                cell = JOptionPane.showInputDialog("Enter cellphone number:");
                
                // If user clicks cancel, exit
                if (cell == null) {
                    System.exit(0);
                }

                if (!checkCellPhoneNumber(cell)) {
                    JOptionPane.showMessageDialog(null, 
                        "Cell number must start with +27 and be 12 digits.");
                }

            } while (!checkCellPhoneNumber(cell));

            // Final check - compare with registered details
            if (username.equals(storedUsername) &&
                password.equals(storedPassword) &&
                cell.equals(storedCellNumber) &&
                firstName.equals(storedFirstName) &&
                lastName.equals(storedLastName)) {

                // Success message
                JOptionPane.showMessageDialog(null,
                    "Welcome " + storedFirstName + " " + storedLastName + 
                    ", it is great to see you again.");

                loggedIn = true;
                loginSuccess = true;
                
               
                // After successful login, start the messaging app
                QuickChat quickChat = new QuickChat();
                quickChat.startQuickChat(storedFirstName, storedLastName);

            } else {
                // If anything is wrong
                JOptionPane.showMessageDialog(null,
                    "Incorrect details, please try again.");
            }
        }
    }
    
    // Method to check if login was successful
    public boolean isLoginSuccessful() {
        return loginSuccess;
    }
}  

