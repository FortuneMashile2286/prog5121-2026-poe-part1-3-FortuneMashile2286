/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mypoepart2.registration;

/**
 *
 * @author fortune
 */
import javax.swing.JOptionPane;
public class Registration {


    // Declaring variables to store user details
    private String username;
    private String password;
    private String cellNumber;
    private String firstName;
    private String lastName;

    // Main method - program starts here
    public static void main(String[] args) {
        
        // Create registration object
        Registration reg = new Registration();
        reg.registerUser(); // Ask user to register

        // Pass registered details to Login class
        Login login = new Login(
                reg.username,
                reg.password,
                reg.cellNumber,
                reg.firstName,
                reg.lastName
        );

        login.startLogin(); // User must login
    }

    // Method to register a new user
    public void registerUser() {
        
        // Get first name
        firstName = JOptionPane.showInputDialog("Enter first name:");
        
        // Get last name
        lastName = JOptionPane.showInputDialog("Enter last name:");

        // Get username and validate
        username = JOptionPane.showInputDialog("Enter username:");
        while (!checkUsername(username)) {
            JOptionPane.showMessageDialog(null, 
                "Username must contain '_' and be max 5 characters.");
            username = JOptionPane.showInputDialog("Enter username:");
        }

        // Get password and validate
        password = JOptionPane.showInputDialog("Enter password:");
        while (!checkPassword(password)) {
            JOptionPane.showMessageDialog(null, 
                "Password must be 8+ chars with capital, number & symbol.");
            password = JOptionPane.showInputDialog("Enter password:");
        }

        // Get cell number and validate
        cellNumber = JOptionPane.showInputDialog("Enter cell number:");
        while (!checkcellNumber(cellNumber)) {
            JOptionPane.showMessageDialog(null, 
                "Cell must start with +27.");
            cellNumber = JOptionPane.showInputDialog("Enter cell number:");
        }

        // Show success message
        JOptionPane.showMessageDialog(null, "Registration successful!");
    }

    // Check if username is valid
    public static boolean checkUsername(String user) {
        return user.contains("_") && user.length() <= 5;
    }

    // Check if password is valid
    public static boolean checkPassword(String pass) {
        if (pass.length() < 8) {
            return false;
        }

        boolean hasCap = false;
        boolean hasNum = false;
        boolean hasSpec = false;

        for (char c : pass.toCharArray()) {
            if (Character.isUpperCase(c)) {
                hasCap = true;
            }
            else if (Character.isDigit(c)) {
                hasNum = true;
            }
            else if (!Character.isLetterOrDigit(c)) {
                hasSpec = true;
            }
        }

        return hasCap && hasNum && hasSpec;
    }

    // Check if cell number is valid
    public static boolean checkcellNumber(String phone) {
        return phone.startsWith("+27");
    }
}
    

